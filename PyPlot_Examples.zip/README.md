Julia_Examples
==============
This is a collection of Julia examples, mostly of PyPlot, which I have created and collected here to link to in other Julia documentation. 

This repository also serves to help me learn about using GitHub so please bear with me as I figure things out.

A [nice layout](https://gist.github.com/gizmaa/7214002) of the examples can be found at the link.